/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

/**
 *
 * @author duong
 */
public abstract class UploadConfig {

    public static final String BASE_UPLOAD_PATH = "C:\\Users\\duong\\Desktop\\SEP490_G16_OPM\\SEP490_G16_OPM\\web\\img\\upload";
    public static final String PIGS_UPLOAD_PATH = BASE_UPLOAD_PATH + "\\pigs";
}
