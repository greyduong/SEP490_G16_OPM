/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dao.ApplicationDAO;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.Date;
import model.Application;

/**
 *
 * @author tuan
 */
@WebServlet(name = "ProcessApplication", urlPatterns = {"/ProcessApplication"})
public class ProcessApplication extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ProcessApplication</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ProcessApplication at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            int applicationId = Integer.parseInt(request.getParameter("applicationId"));
            String action = request.getParameter("action"); // "approve", "reject", or "reply"
            ApplicationDAO dao = new ApplicationDAO();
            Application application = dao.getApplicationById(applicationId);

            if (application != null) {
                // Handle approve or reject actions
                if ("approve".equalsIgnoreCase(action)) {
                    application.setStatus("Approved");
                } else if ("reject".equalsIgnoreCase(action)) {
                    application.setStatus("Rejected");
                } else if ("reply".equalsIgnoreCase(action)) {
                    // Handle reply action
                    String replyText = request.getParameter("reply");
                    application.setReply(replyText);
                    application.setStatus("Replied"); // You can also set a specific status for replies
                }

                application.setProcessingDate(new Date());
                boolean updated = dao.updateApplication(application);

                if (updated) {
                    request.getSession().setAttribute("successMsg", "Application processed successfully.");
                } else {
                    request.getSession().setAttribute("errorMsg", "Failed to update application.");
                }
            } else {
                request.getSession().setAttribute("errorMsg", "Application not found.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute("errorMsg", "An error occurred while processing the application.");
        }

        response.sendRedirect("StaffViewApplication");
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
