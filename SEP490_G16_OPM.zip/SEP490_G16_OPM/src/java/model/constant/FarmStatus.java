package model.constant;

public enum FarmStatus {
    PENDING, REJECT, ACTIVE, INACTIVE;
}
